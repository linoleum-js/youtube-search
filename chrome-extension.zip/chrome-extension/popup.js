// chrome.extension.getBackgroundPage().reload();
console.log('RELOADED');